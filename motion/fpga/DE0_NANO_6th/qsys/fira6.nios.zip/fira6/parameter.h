#ifndef PARAMETER_H
#define PARAMETER_H
#define VERSION	FIRA_6_01
#define HEAD_1 0xf6
#define HEAD_2 0x01

#endif
