#ifndef PARAMETER_H
#define PARAMETER_H
#define VERSION	FIRA_7_01
#define HEAD_1 0xf7
#define HEAD_2 0x01

#endif
